#!/usr/bin/env node
import { mkdir, readFile, writeFile, access, lstat } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import {
  buildDeftAppPackage,
  canonicalDeftAppRequestedAuthorityReportJson,
  checkDeftAppDeveloperContract,
  DeftAppLockV2Schema,
  DEFT_APP_KIT_PACKAGE_NAME,
  DEFT_APP_KIT_VERSION,
  DEFT_APP_PACKAGE_FORMAT,
  DEFT_APP_REQUESTED_AUTHORITY_REPORT_PATH,
  diffDeftAppRequestedAuthority,
  parseDeftAppManifest,
  prepareModuleArtifact,
  prepareDeftExperienceArtifact,
  DEFT_EXPERIENCE_BUNDLE_VERSION,
  DEFT_EXPERIENCE_BRIDGE_VERSION,
  DEFT_EXPERIENCE_RENDERER_VERSION,
  simulateDeftAppAutomation,
  type DeftAppAutomationSimulationInput,
  type DeftAppManifestInput,
  type DeftAppManifestV0Input,
  type DeftAppManifestV1Input,
  type DeftAppManifestV2Input,
} from './index.js';

const cwd = process.cwd();

async function exists(path: string): Promise<boolean> {
  try { await access(path); return true; } catch { return false; }
}

async function writeJson(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

async function assertRegularUnslinkedFile(relativePath: string): Promise<string> {
  let current = cwd;
  for (const segment of relativePath.split('/')) {
    current = resolve(current, segment);
    const stat = await lstat(current);
    if (stat.isSymbolicLink()) throw new Error(`App artifacts cannot traverse symbolic links: ${relativePath}`);
  }
  const stat = await lstat(current);
  if (!stat.isFile()) throw new Error(`App artifact is not a regular file: ${relativePath}`);
  return current;
}

type AppTemplate = 'declarative' | 'connected' | 'connected-automation' | 'runtime' | 'installed';

function parseInitTemplate(): AppTemplate {
  const args = process.argv.slice(4);
  if (args.length === 0) return 'declarative';
  if (
    args.length !== 2
    || args[0] !== '--template'
    || (args[1] !== 'declarative' && args[1] !== 'connected' && args[1] !== 'connected-automation' && args[1] !== 'runtime' && args[1] !== 'installed')
  ) {
    throw new Error('Usage: deft app init [--template declarative|connected|connected-automation|runtime|installed]');
  }
  return args[1];
}

async function initializeDeclarative(): Promise<void> {
  const manifestPath = resolve(cwd, 'deft.app.json');
  if (await exists(manifestPath)) throw new Error('deft.app.json already exists');
  const modulePath = 'modules/hello-workspace/deft.module.json';
  const moduleManifest = {
    schema_version: '1',
    id: 'community.example.hello-workspace',
    slug: 'hello-workspace',
    version: '1.0.0',
    name: 'Hello Workspace',
    description: 'A minimal declarative App authored outside Deft core.',
    collections: [{
      key: 'greetings',
      name: 'Greetings',
      singular_name: 'Greeting',
      fields: [{ key: 'message', label: 'Message', type: 'text', required: true }],
      views: [{ key: 'all', name: 'All greetings', type: 'table', fields: ['message'] }],
      search: { title_field: 'message', subtitle_fields: [], fields: ['message'] },
    }],
    navigation: { default_collection: 'greetings', default_view: 'all' },
  };
  const artifact = await prepareModuleArtifact({ path: modulePath, manifest: moduleManifest });
  const manifest: DeftAppManifestV0Input = {
    schema_version: '0',
    id: 'community.example.hello-workspace-app',
    version: '1.0.0',
    name: 'Hello Workspace',
    description: 'My first declarative Deft App.',
    license: 'AGPL-3.0-only',
    compatibility: { app_protocol: '0' },
    modules: [{
      module_id: moduleManifest.id,
      version: moduleManifest.version,
      manifest_path: modulePath,
      manifest_digest: artifact.digest,
    }],
    navigation: [{
      key: 'greetings', label: 'Greetings', module_id: moduleManifest.id,
      collection_key: 'greetings', view_key: 'all',
    }],
  };
  await writeJson(resolve(cwd, modulePath), moduleManifest);
  await writeJson(manifestPath, manifest);
  await writeFile(resolve(cwd, 'APP_BRIEF.md'), '# App brief\n\nDescribe the workspace outcome this App should provide.\n', 'utf8');
  await writeFile(resolve(cwd, 'AGENTS.md'), [
    '# Declarative Deft App',
    '',
    '- Build this App through `deft.app.json` and included `deft.module.json` files.',
    '- Do not edit Deft core, add executable code, embed secrets, declare network egress, or self-grant permissions.',
    '- App Protocol v0 has no capabilities, connectors, runtime, sync, automation, public routes, or custom UI.',
    '- Keep App license and provenance metadata explicit; generated files are declarative data.',
    '',
  ].join('\n'), 'utf8');
  await writeFile(resolve(cwd, '.gitignore'), '.deft/\n', 'utf8');
  console.log(`Initialized ${manifest.name} in ${cwd}`);
}

async function initializeConnected(automation: boolean): Promise<void> {
  const manifestPath = resolve(cwd, 'deft.app.json');
  if (await exists(manifestPath)) throw new Error('deft.app.json already exists');
  const modulePath = 'modules/connected-campaigns/deft.module.json';
  const moduleManifest = {
    schema_version: '2',
    id: 'community.example.connected-campaigns',
    slug: 'connected-campaigns',
    version: '1.0.0',
    name: 'Connected Campaigns',
    description: 'Campaign resources that reference Contacts owned by a dependency App.',
    collections: [{
      key: 'campaigns',
      name: 'Campaigns',
      singular_name: 'Campaign',
      fields: [
        { key: 'subject', label: 'Subject', type: 'text', required: true },
        { key: 'body', label: 'Body', type: 'long_text', required: true },
        {
          key: 'contacts',
          label: 'Contacts',
          type: 'resource_ref',
          target: { module_id: 'org.deft.reference.resource-contacts', resource_type: 'contacts' },
          multiple: true,
          display: 'label',
        },
      ],
      views: [
        { key: 'all', name: 'All campaigns', type: 'table', fields: ['subject', 'contacts'] },
        { key: 'detail', name: 'Campaign details', type: 'detail', fields: ['subject', 'body', 'contacts'] },
      ],
      search: { title_field: 'subject', subtitle_fields: [], fields: ['subject', 'body'] },
    }],
    navigation: { default_collection: 'campaigns', default_view: 'all' },
  };
  const artifact = await prepareModuleArtifact({ path: modulePath, manifest: moduleManifest });
  const connectedManifest: Omit<DeftAppManifestV1Input, 'schema_version' | 'compatibility'> = {
    id: 'community.example.connected-campaigns-app',
    version: '1.0.0',
    name: 'Connected Campaigns',
    description: 'A connected Deft App that relates Campaigns to Contacts and requests sandbox email.',
    license: 'AGPL-3.0-only',
    modules: [{
      module_id: moduleManifest.id,
      version: moduleManifest.version,
      manifest_path: modulePath,
      manifest_digest: artifact.digest,
    }],
    navigation: [{
      key: 'campaigns', label: 'Campaigns', module_id: moduleManifest.id,
      collection_key: 'campaigns', view_key: 'all',
    }],
    dependencies: [{
      key: 'contacts_app',
      app_id: 'org.deft.reference.resource-contacts-app',
      version: '1.0.0',
    }],
    resource_requirements: [
      {
        key: 'campaign',
        source: { kind: 'included_module', module_id: moduleManifest.id, version: moduleManifest.version },
        resource_type: 'campaigns',
        fields: ['subject', 'body', 'contacts'],
      },
      {
        key: 'contact',
        source: {
          kind: 'dependency_module',
          dependency_key: 'contacts_app',
          module_id: 'org.deft.reference.resource-contacts',
          version: '1.0.0',
        },
        resource_type: 'contacts',
        fields: ['email'],
      },
    ],
    capability_requirements: [{
      key: 'send_email',
      interface: {
        kind: 'private', namespace: 'app_lineage', key: 'sandbox_email_send', version: '1',
      },
    }],
    connector_requirements: [{ key: 'mail_provider', provider_kind: 'mcp' }],
    actions: [{
      key: 'send_campaign_email',
      label: 'Send campaign email',
      capability_requirement_key: 'send_email',
      connector_requirement_key: 'mail_provider',
      placement: { kind: 'resource_detail', resource_requirement_key: 'campaign' },
      input_bindings: [
        {
          input_key: 'to',
          source: {
            kind: 'selected_relation_field',
            source_resource_requirement_key: 'campaign',
            relation_field_key: 'contacts',
            target_resource_requirement_key: 'contact',
            target_field_key: 'email',
            selection: 'one',
          },
        },
        {
          input_key: 'subject',
          source: { kind: 'resource_field', resource_requirement_key: 'campaign', field_key: 'subject' },
        },
        {
          input_key: 'body_text',
          source: { kind: 'resource_field', resource_requirement_key: 'campaign', field_key: 'body' },
        },
      ],
    }],
  };
  const manifest: DeftAppManifestV1Input | DeftAppManifestV2Input = automation
    ? {
        ...connectedManifest,
        schema_version: '2',
        compatibility: { app_protocol: '2' },
        automation_requests: [{
          key: 'daily_campaign_send',
          label: 'Daily campaign send',
          trigger: { kind: 'daily_local_time' },
          action_key: 'send_campaign_email',
        }],
      }
    : {
        ...connectedManifest,
        schema_version: '1',
        compatibility: { app_protocol: '1' },
      };
  await writeJson(resolve(cwd, modulePath), moduleManifest);
  await writeJson(manifestPath, manifest);
  await writeFile(resolve(cwd, 'APP_BRIEF.md'), [
    '# App brief',
    '',
    'Describe the connected workspace outcome, the resources it relates, and why each requested authority is needed.',
    '',
  ].join('\n'), 'utf8');
  await writeFile(resolve(cwd, 'AGENTS.md'), [
    '# Connected Deft App',
    '',
    '- Build only through the published `@deft/app-kit` manifest, Module, and package contracts.',
    '- Keep staging at zero authority. A workspace owner or admin reviews, binds, and activates requests.',
    '- Never add credentials, provider endpoints, executable code, arbitrary mapping, policy overrides, or Deft core edits.',
    '- Keep Contacts as an exact dependency and reference its records; do not copy them into Campaigns.',
    automation
      ? '- The automation request is declarative and requested-only. The host owns schedule, timezone, pins, budgets, policy, approval, and execution.'
      : '- The sandbox email action is single-recipient, human-initiated, and always requires host review.',
    automation
      ? '- App Protocol v2 provides only bounded daily scheduling; it does not provide workflows, custom UI, runtime, sync, or public ingress.'
      : '- App Protocol v1 does not provide automation, custom UI, runtime, sync, or public ingress.',
    '',
  ].join('\n'), 'utf8');
  await writeFile(resolve(cwd, '.gitignore'), '.deft/\n', 'utf8');
  console.log(`Initialized ${manifest.name} in ${cwd}`);
}

async function initialize(template: AppTemplate): Promise<void> {
  if (template === 'runtime' || template === 'installed') {
    if (await exists(resolve(cwd, 'deft.app.json'))) throw new Error('deft.app.json already exists');
    let included: DeftAppManifestV0Input | undefined;
    let installed: Record<string, unknown> = {};
    if (template === 'installed') {
      await initializeDeclarative();
      included = JSON.parse(await readFile(resolve(cwd, 'deft.app.json'), 'utf8')) as DeftAppManifestV0Input;
      const bundle = { schema_version: DEFT_EXPERIENCE_BUNDLE_VERSION, entry_view: 'main', resource_keys: [],
        action_keys: ['create_shipping_label'],
        worker_source: `self.onmessage = ({data}) => {
  if (data.kind !== 'start' || !data.port) return;
  const port = data.port; let sequence = 0; let shipment = ''; let status = 'Enter a shipment identifier.';
  const send = (message) => port.postMessage({version:'deft.experience_bridge.v1',session_id:data.session_id,sequence:++sequence,...message});
  const render = () => send({kind:'view',view:{root:{kind:'stack',id:'main',title:'Shipping Label',children:[
    {kind:'text',id:'help',text:'Create a label for a shipment. You will review and approve the request before it runs.'},
    {kind:'input',id:'shipment',label:'Shipment identifier',value:shipment},
    {kind:'button',id:'create',label:'Create shipping label'}, {kind:'text',id:'status',text:status}]}}});
  port.onmessage = ({data:message}) => {
    if (message.version !== 'deft.experience_bridge.v1' || message.session_id !== data.session_id) return;
    if (message.kind === 'ui_event' && message.event?.kind === 'input' && message.event.node_id === 'shipment') shipment=String(message.event.value).slice(0,120);
    if (message.kind === 'ui_event' && message.event?.kind === 'click' && message.event.node_id === 'create') {
      if (!shipment) {status='Enter a shipment identifier.'; render(); return;}
      send({kind:'request',request_id:'request_'+(sequence+1),operation:'action',key:'create_shipping_label',input:{shipment_id:shipment}});
      status='Submitting for review…'; render();
    }
    if (message.kind === 'response') { status=message.ok ? 'Submitted. Open approvals to review the exact input.' : 'Request unavailable. Check the App configuration and try again.'; render(); }
  };
  render();
};` };
      const artifact = await prepareDeftExperienceArtifact('experiences/main.json', bundle);
      await mkdir(resolve(cwd, 'experiences'), { recursive: true });
      await writeFile(resolve(cwd, artifact.path), artifact.content, 'utf8');
      installed = { experiences: [{ key: 'main', label: 'Shipping Label', artifact_path: artifact.path,
        artifact_digest: artifact.digest, bridge_version: DEFT_EXPERIENCE_BRIDGE_VERSION,
        renderer_version: DEFT_EXPERIENCE_RENDERER_VERSION }],
        public_actions: [{ key: 'claim_label', action_key: 'create_shipping_label',
          module_id: included.modules[0]!.module_id, collection_key: 'greetings',
          input_mapping: { shipment_id: 'claim.resource_id' } }] };
      await writeFile(resolve(cwd, 'AGENTS.md'), '# Installed Runtime App\n\nUse the version-matched public App Kit. Keep author Worker code in the Experience bundle and all credentials outside the App. Runtime bindings and public endpoints require host review; every external action requires approval.\n');
    }
    await writeJson(resolve(cwd, 'deft.app.json'), {
      schema_version: template === 'installed' ? '4' : '3', id: 'community.example.shipping', version: '1.0.0',
      name: 'Shipping Label', license: 'AGPL-3.0-only', compatibility: { app_protocol: template === 'installed' ? '4' : '3' },
      modules: included?.modules ?? [], navigation: included?.navigation ?? [], ...installed,
      runtime_requirements: [{ key: 'carrier', protocol_version: 'deft.app_runtime_channel.v1' }],
      private_capabilities: [{ key: 'create_shipping_label', version: '1',
        input_schema: { type: 'object', properties: { shipment_id: { type: 'string', maxLength: 120 } }, required: ['shipment_id'], additionalProperties: false },
        output_schema: { type: 'object', properties: { label_id: { type: 'string', maxLength: 120 } }, required: ['label_id'], additionalProperties: false },
      }],
      runtime_actions: [{ key: 'create_shipping_label', label: 'Create shipping label', capability_key: 'create_shipping_label', runtime_requirement_key: 'carrier' }],
    });
    await writeFile(resolve(cwd, 'APP_BRIEF.md'), '# Shipping Label\n\nCandidate Runtime App. Build and stage with the public Kit. A workspace operator must review the App and separately register and bind the external Runtime. Every invocation requires approval. Never place provider credentials or commands in this package.\n');
    console.log('Initialized candidate Runtime App; no provider authority granted.');
    return;
  }
  if (template === 'connected' || template === 'connected-automation') {
    return initializeConnected(template === 'connected-automation');
  }
  return initializeDeclarative();
}

async function buildProject(writeOutput: boolean) {
  const source = JSON.parse(await readFile(resolve(cwd, 'deft.app.json'), 'utf8')) as DeftAppManifestInput;
  const artifacts: Parameters<typeof buildDeftAppPackage>[0]['artifacts'] = [];
  const modules = [];
  for (const reference of source.modules ?? []) {
    const raw = JSON.parse(await readFile(await assertRegularUnslinkedFile(reference.manifest_path), 'utf8')) as unknown;
    const artifact = await prepareModuleArtifact({ path: reference.manifest_path, manifest: raw });
    artifacts.push(artifact);
    modules.push({ ...reference, manifest_digest: artifact.digest });
  }
  const experiences = source.schema_version === '4' || source.schema_version === '5' || source.schema_version === '6' ? await Promise.all(source.experiences.map(async (reference) => {
    const raw = JSON.parse(await readFile(await assertRegularUnslinkedFile(reference.artifact_path), 'utf8')) as unknown;
    const artifact = await prepareDeftExperienceArtifact(reference.artifact_path, raw);
    artifacts.push(artifact);
    return { ...reference, artifact_digest: artifact.digest };
  })) : undefined;
  const manifest = parseDeftAppManifest({ ...source, modules, ...(experiences ? { experiences } : {}) });
  const built = await buildDeftAppPackage({ manifest, artifacts });
  if (writeOutput) {
    await mkdir(resolve(cwd, '.deft'), { recursive: true });
    await writeFile(resolve(cwd, '.deft', 'app.deftapp.json'), `${built.json}\n`, 'utf8');
    const baseLock = {
      schema: `deft.app.lock.v${manifest.schema_version}`,
      app_id: manifest.id,
      version: manifest.version,
      package_digest: built.digest,
      manifest_digest: built.package.manifest_digest,
      artifacts: built.package.artifacts.map(({ path, digest, byte_length, media_type }) => ({ path, digest, byte_length, media_type })),
      permissions: [],
    };
    const permissionDiff = manifest.schema_version === '2'
      ? await diffDeftAppRequestedAuthority({ proposed: manifest })
      : null;
    const lock = permissionDiff
      ? DeftAppLockV2Schema.parse({
          ...baseLock,
          requested_authority_digest: permissionDiff.proposed_requested_authority_digest,
          permission_diff: permissionDiff,
        })
      : baseLock;
    await writeJson(resolve(cwd, 'deft.app.lock.json'), lock);
    await writeFile(
      resolve(cwd, DEFT_APP_REQUESTED_AUTHORITY_REPORT_PATH),
      `${canonicalDeftAppRequestedAuthorityReportJson(manifest)}\n`,
      'utf8',
    );
  }
  return built;
}

function option(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

async function hostUrl(): Promise<string> {
  return (option('--url') ?? process.env.DEFT_URL ?? 'http://localhost:3001').replace(/\/$/, '');
}

type DeveloperStatus = {
  app_protocol?: string;
  audience?: string;
  single_use_install?: boolean;
  compatibility?: unknown;
};

async function readDeveloperStatus(url: string): Promise<DeveloperStatus> {
  const response = await fetch(`${url}/api/app-developer/status`);
  if (!response.ok) throw new Error(`Deft App developer pairing is unavailable at ${url} (${response.status})`);
  const status = await response.json() as DeveloperStatus;
  if (
    status.app_protocol !== '0'
    || status.audience !== 'app-developer'
    || status.single_use_install !== true
  ) {
    throw new Error('Host does not implement the Deft App developer pairing contract');
  }
  return status;
}

async function compatibleFlow(url: string, built: Awaited<ReturnType<typeof buildProject>>) {
  const status = await readDeveloperStatus(url);
  const protocol = built.package.manifest.compatibility.app_protocol;
  const flow = status.compatibility === undefined
    ? (() => {
        if (protocol !== '0') throw new Error('Host supports only App Protocol v0 developer installs');
        return { package_format: DEFT_APP_PACKAGE_FORMAT, install_mode: 'stage_and_activate' as const };
      })()
    : (await checkDeftAppDeveloperContract({
        package_json: built.json,
        host_compatibility: status.compatibility,
      })).install_flow;
  if (flow.package_format !== built.package.package_format) {
    throw new Error(`Host advertises an incompatible package format for App Protocol v${protocol}`);
  }
  return flow;
}

async function doctor(): Promise<void> {
  const built = await buildProject(false);
  const url = await hostUrl();
  const flow = await compatibleFlow(url, built);
  const protocol = built.package.manifest.compatibility.app_protocol;
  console.log(
    `Compatible App Kit package ${DEFT_APP_KIT_PACKAGE_NAME} version ${DEFT_APP_KIT_VERSION}; `
    + `App Protocol v${protocol}; package format ${flow.package_format}; `
    + `install mode ${flow.install_mode}; host ${url}`,
  );
  if (protocol === '2') {
    console.log('Bounded automation contracts ready; run `deft app simulate-automation --fixture <path>` before staging.');
  }
}

async function permissionsDiff(): Promise<void> {
  const current = JSON.parse(await readFile(resolve(cwd, 'deft.app.json'), 'utf8')) as unknown;
  const from = option('--from');
  const prior = from
    ? JSON.parse(await readFile(await assertRegularUnslinkedFile(from), 'utf8')) as unknown
    : null;
  console.log(JSON.stringify(await diffDeftAppRequestedAuthority({
    ...(prior === null ? {} : { prior: parseDeftAppManifest(prior) }),
    proposed: parseDeftAppManifest(current),
  }), null, 2));
}

async function simulateAutomation(): Promise<void> {
  const fixture = option('--fixture');
  if (!fixture) throw new Error('Usage: deft app simulate-automation --fixture <path>');
  const manifest = parseDeftAppManifest(
    JSON.parse(await readFile(resolve(cwd, 'deft.app.json'), 'utf8')) as unknown,
  );
  if (manifest.schema_version !== '2') {
    throw new Error('Automation simulation requires an App Protocol v2 manifest');
  }
  const scenario = JSON.parse(
    await readFile(await assertRegularUnslinkedFile(fixture), 'utf8'),
  ) as Record<string, unknown>;
  console.log(JSON.stringify(simulateDeftAppAutomation({
    ...scenario,
    manifest,
  } as DeftAppAutomationSimulationInput), null, 2));
}

async function readPairingCode(): Promise<string> {
  if (!stdin.isTTY) {
    const chunks: Buffer[] = [];
    for await (const chunk of stdin) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks).toString('utf8').trim();
  }
  const reader = createInterface({ input: stdin, output: stdout });
  try { return (await reader.question('One-time pairing code: ')).trim(); }
  finally { reader.close(); }
}

async function installLocal(): Promise<void> {
  const url = await hostUrl();
  const built = await buildProject(true);
  const flow = await compatibleFlow(url, built);
  const code = await readPairingCode();
  if (!code) throw new Error('A one-time pairing code is required on stdin');
  const exchange = await fetch(`${url}/api/app-developer/pair/exchange`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code }),
  });
  if (!exchange.ok) throw new Error(`Pairing failed (${exchange.status}): ${await exchange.text()}`);
  const { token } = await exchange.json() as { token: string };
  const installed = await fetch(`${url}/api/app-developer/install`, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/vnd.deft.app.package+json' },
    body: built.json,
  });
  if (!installed.ok) throw new Error(`Install failed (${installed.status}): ${await installed.text()}`);
  const result = await installed.json() as { app: { name: string; state: string } };
  console.log(flow.install_mode === 'stage_only'
    ? `Staged ${result.app.name} (${result.app.state}) for workspace review.`
    : `Installed ${result.app.name} (${result.app.state})`);
}

async function main(): Promise<void> {
  const [domain, command] = process.argv.slice(2);
  if (domain !== 'app') throw new Error('Usage: deft app <init|check|build|permissions|simulate-automation|doctor|install-local>');
  if (command === 'init') return initialize(parseInitTemplate());
  if (command === 'check') {
    const built = await buildProject(false);
    const protocol = built.package.manifest.compatibility.app_protocol;
    if (protocol === '0') {
      console.log(`Valid App Protocol v0 package ${built.digest}; connected permissions: none`);
    } else if (protocol === '1') {
      console.log(`Valid App Protocol v1 connected package ${built.digest}; staging grants zero authority; review and activation are explicit; execution is rollout-gated`);
    } else if (protocol === '3') {
      console.log(`Valid App Protocol v3 Runtime package ${built.digest}; staging grants zero authority; App and Runtime binding reviews are required`);
    } else if (protocol === '5') {
      console.log(`Valid App Protocol v5 resource Runtime authoring package ${built.digest}; requested authority only; this host does not support installation yet`);
    } else if (protocol === '4') {
      console.log(`Valid App Protocol v4 installed Experience package ${built.digest}; staging grants zero authority; App and Runtime binding reviews are required`);
    } else {
      console.log(`Valid App Protocol v2 automation-request package ${built.digest}; staging grants zero authority; automation requests are requested-only and non-executable; provider access: none`);
    }
    return;
  }
  if (command === 'build') {
    const built = await buildProject(true);
    console.log(`Built .deft/app.deftapp.json ${built.digest}`);
    return;
  }
  if (command === 'permissions' && process.argv[4] === 'diff') return permissionsDiff();
  if (command === 'simulate-automation') return simulateAutomation();
  if (command === 'doctor') return doctor();
  if (command === 'install-local') return installLocal();
  throw new Error('Usage: deft app <init|check|build|permissions|simulate-automation|doctor|install-local>');
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
