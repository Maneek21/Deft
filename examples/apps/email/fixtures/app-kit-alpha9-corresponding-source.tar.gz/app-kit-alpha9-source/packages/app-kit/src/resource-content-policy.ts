import { z } from 'zod';
import { RuntimeObjectSchema } from './runtime-authoring.js';
const key = z.string().regex(/^[a-z][a-z0-9_]{0,47}$/u)
  .refine(value => !['constructor', 'prototype', '__proto__'].includes(value));
/** Additional current document disclosure, reviewed separately from saved
 * scalar metadata. Provider and account selection remain host-owned. */
export const ResourceContentPolicySchema = z.strictObject({
  document: z.strictObject({ max_characters: z.number().int().min(1).max(16384),
    metadata_schema: RuntimeObjectSchema.optional() }),
});
export const ResourceContentDeclarationSchema = z.strictObject({ resource_key: key, ...ResourceContentPolicySchema.shape });
export const ResourceContentDeclarationsSchema = z.array(ResourceContentDeclarationSchema).min(1).max(16)
  .refine(rows => rows.every((row, index) => !index || rows[index - 1]!.resource_key < row.resource_key),
    'Resource content declarations must be unique and sorted');
export type ResourceContentPolicy = z.infer<typeof ResourceContentPolicySchema>;
