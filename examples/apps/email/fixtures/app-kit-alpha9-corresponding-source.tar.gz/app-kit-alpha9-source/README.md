# Historical SDK fixture corresponding source

This is preferred TypeScript source and build input for the immutable SDK archive
`deft-app-kit-0.1.0-alpha.9.tgz` used only by retained legacy Email regression tests.
Archive SHA256: `ac324a4906c4fade1e463a0808dc111cfa71dcd41901272c519cf6c4a73925bc`.
Its original metadata says alpha.9; its exported contract identity says alpha.7.
That mismatch is preserved. This is not an advertised supported authoring SDK,
a replacement for current alpha.32, or permission to change the legacy lock pin.

Original package metadata, all SDK TypeScript source, original build script and
TypeScript configuration, and the three authoritative shared schema sources are
included unchanged. PACKED-README.md preserves the packed original documentation.
The root toolchain manifest/lock and reconstruction script are added to make the
existing source correspondence verifiable without private retained archives.

Using Node 22 and pnpm 10.33.1, run:

```sh
pnpm install --ignore-workspace --frozen-lockfile
node reconstruct-javascript.mjs
```

The script emits all 27 JavaScript modules and verifies every emitted byte against
PACKED-JAVASCRIPT.json. It reproduces the original tsc ES2022/ESNext options and
the original build-module-validator transpilation for three shared modules.
It does not rebuild/repack or overwrite the frozen SDK archive. Source maps and
TypeScript declarations remain in the original archive. The original package
build script can generate declarations with the included source and pinned tools.

The source is AGPL-3.0-only; see LICENSE. No credentials or deployment data are included.
